package com.example.saksh.myapplication;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.brillicaservices.gurjas.studentmanagementsystem.R;

import static com.brillicaservices.gurjas.studentmanagementsystem.R.*;

public class MainActivity extends AppCompatActivity {

    /*
     * Declaring global variables*/
    EditText email, password;

    Button login,newuser,forgotpassword;
    TextView em,pw,log;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        email = findViewById(id.text1);
        password = findViewById(id.text2);
        login = findViewById(id.button1);
        newuser = findViewById(id.button2);
        forgotpassword = findViewById(id.text28);
        em = findViewById(id.text26);
        pw = findViewById(id.text27);
        log = findViewById(id.text25);



        /*
         * setting button onClickListener*/
        newuser.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                /* getting input from customer like customerName, capacity and quantity of coffee*/
                String name = email.getText().toString();
                int pass = Integer.parseInt(password.getText().toString());


                Toast.makeText(getApplicationContext(), " data saved successfully", Toast.LENGTH_LONG).show();


            }

        });
    }
}